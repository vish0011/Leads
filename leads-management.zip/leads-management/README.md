# Angular Leads Management Project

## Overview
This project is an Angular application designed for managing leads. It allows users to authenticate, view, and paginate through leads data.

## Prerequisites
Before you begin, ensure you have the following installed:

- [Node.js](https://nodejs.org/) (version 14 or higher)
- [Angular CLI](https://angular.io/cli) (installed globally)

## Installation

1. **Clone the repository**
   ```bash
   git clone "giturl"
   cd leads-management

## node modules install

npm install

## start the server  
ng serve 