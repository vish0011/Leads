import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component'; 
import { LeaderComponent } from './leader/leader.component';
import { AuthGuard } from './auth/auth.guard';

export const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' }, 
    { path: 'login', component: LoginComponent }, 
    { path: 'leader', loadComponent: () => import('./leader/leader.component').then(m => m.LeaderComponent), canActivate: [AuthGuard] } // Apply the guard
];
 
