import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule, NgFor, NgIf } from '@angular/common';

interface Lead {
  id: number;
  name: string;
  phone: string;
  email: string;
  priority: number;
  lead_type: string;
  lead_assigned_by_user_name: string; // Lead Owner
}

@Component({
  selector: 'app-leader',
  standalone: true,
  templateUrl: './leader.component.html',
  styleUrls: ['./leader.component.css'],
  imports: [CommonModule, HttpClientModule, ReactiveFormsModule, NgIf, NgFor],
})
export class LeaderComponent implements OnInit {
  loginForm: FormGroup;
  leads: Lead[] = [];
  errorMessage: string = '';
  currentPage: number = 1;
  totalPages: number = 0;  
  private authUrl = 'https://dev-cc.automateazy.com/api/v1/users/auth';
  private leadsUrl = 'https://dev-cc.automateazy.com/api/v1/getLeads';

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.fetchLeads();
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const credentials = {
        username: this.loginForm.value.email,
        password: this.loginForm.value.password
      };

      this.login(credentials);
    }
  }

  private login(credentials: { username: string; password: string }) {
    this.http.post(this.authUrl, credentials).subscribe({
      next: (response: any) => {
        if (response.token) {
          localStorage.setItem('token', response.token);
          this.fetchLeads();
        } else {
          this.errorMessage = 'Token is missing in the response';
        }
      },
      error: () => {
        this.errorMessage = 'Invalid credentials';
      }
    });
  }

  private fetchLeads(pageNo = 1) {
    const token = localStorage.getItem('token');
    if (!token) {
      this.errorMessage = 'No token found';
      return;
    }

    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    const body = {
      "id": "",
    "name": "",
    "priority": "",
    "lead_type": "all",
    "isUntouched": 0,
    "source": "",
    "sdate": "",
    "edate": "",
    "uStartDate": "",
    "uEndDate": "",
    "activitySDate": "",
    "activityEndDate": "",
    "user_role": 1,
    "vc": 0,
    "page_no": pageNo ? pageNo:1,
    "limit": 10,
    "type": "",
    "leadStageCreator": "",
    "firstStageLeadAction": "",
    "secondStageLeadAction": "",
    "thirdStageLeadAction": "",
    "fourthStageLeadAction": "",
    "fifthStageLeadAction": "",
    "lastFirstStageLeadAction": "",
    "lastSecondStageLeadAction": "",
    "lastThirdStageLeadAction": "",
    "lastFouthStageLeadAction": "",
    "lastFifthStageLeadAction": "",
    "sub_stage": "",
    "allleadaction": "",
    "clgId": "",
    "sortKey": "lead_times_at",
    "sortOrder": "-1",
    "format": "search",
    "accessAllLeads": 1,
    "state": "",
    "city": "",
    "course": "",
    "stateName": "",
    "cityName": "",
    "courseName": "",
    "category": "",
    "noOfReEnquiry": "",
    "reEnquiryOperation": "",
    "noOfApplicationForm": "",
    "applicationFormOperation": "",
    "lead_score": "",
    "leadScoreOpreation": "",
    "lead_stage_count": "",
    "leadStageCountOpreation": "",
    "recentReEnquiredAtOperation": "",
    "lastReEnquiredAtOperation": "",
    "recentLeadStageAtOperation": "",
    "leadActivityAtOperation": "",
    "createdAtOperation": "",
    "updatedAtOperation": "",
    "leadAssignAtOperation": "",
    "reEnquiredClg": "",
    "lastReEnquiredClg": "",
    "reEnquiredClgSource": "",
    "reEnquiredsdate": "",
    "reEnquirededate": "",
    "reLastEnquiredsdate": "",
    "reLastEnquirededate": "",
    "utmSource": "",
    "utmCampaign": "",
    "utmMedium": "",
    "reEnquiredUtmSource": "",
    "reEnquiredUtmMedium": "",
    "reEnquiredUtmCampaign": "",
    "fw_sdate": "",
    "fw_edate": "",
    "n_id": "",
    "recentLeadStageStartDate": "",
    "recentLeadStageEndDate": "",
    "leadAssigneeStartDate": "",
    "leadAssigneeEndDate": "",
    "oldUserId": "",
    "reAssignedUserId": "",
    "activity_event": "",
    "publisher_tenant_id": "",
    "org_location_name": "",
    "sinceLeadOwnerChange": "",
    "createdAtAgeTimeGap": "",
    "ownerAssignmentAtAgeTimeGap": "",
    "stageCreatedAtAgeTimeGap": " ",
    "primary_source": "",
    "secondary_source": "",
    "tertiary_source": "",
    "last_source": ""
    };
    // these data will be shown on web page
    this.http.post(this.leadsUrl, body, { headers }).subscribe({
      next: (response: any) => {
        if (response.success) {
          this.leads = response.data.map((lead: any) => ({
            id: lead.id,
            name: lead.name,
            phone: lead.phone,
            email: lead.email,
            priority: lead.priority,
            lead_type: lead.lead_type,
            lead_assigned_by_user_name: lead.lead_assigned_by_user_name
          }));
          this.totalPages = response.totalPages;  
        } else {
          this.errorMessage = 'No leads found';
          this.totalPages = 0;  
        }
      },
      error: (err) => {
        console.error('Error fetching leads:', err);
        this.errorMessage = 'Failed to fetch leads data';
      }
    });
  }
  
   // Method to show the page data , pagination
   changePage(page: number) {
    if (page < 1 || page > this.totalPages) return; 
    this.currentPage = page;
    this.fetchLeads(this.currentPage);
  }
}
