import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router'; 
import { CommonModule } from '@angular/common';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    CommonModule
  ]
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8), this.passwordValidator]]
    });
  }
 

  // Custom validator for password strength
  passwordValidator(control: any) {
    const value = control.value;
    if (value) {
      const hasUpperCase = /[A-Z]/.test(value);
      const hasLowerCase = /[a-z]/.test(value);
      const hasNumeric = /\d/.test(value);
      const hasSpecial = /[!@#$%^&*]/.test(value);
      const valid = hasUpperCase && hasLowerCase && hasNumeric && hasSpecial;
      return valid ? null : { weakPassword: true };
    }
    return null;
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const credentials = {
        username: this.loginForm.value.email,
        password: this.loginForm.value.password
      };

      this.http.post('https://dev-cc.automateazy.com/api/v1/users/auth', credentials)
        .subscribe({
          next: (response: any) => {
            if (response.result && response.result.token) {
              localStorage.setItem('token', response.result.token);
              this.router.navigateByUrl("/leader");
            } else {
              this.showError('Token is missing in the response');
            }
          },
          error: () => {
            this.showError('Invalid credentials');
          }
        });
    } else {
      this.showError('Please fill in all required fields correctly.');
    }
  }
  // sweet alert for wrong token
  showError(message: string) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: message,
      confirmButtonText: 'OK'
    });
  }
}
